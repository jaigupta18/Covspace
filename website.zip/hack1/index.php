<?php
    $name=$_POST["name"];
    $reason=$_POST["Reason"];
    $add1=$_POST["Add1"];
    $email=$_POST["email"];
    $phone=$_POST["phone"];
    $data=array(
        "name" => $name,
        "reason" => $reason,
        "address1" => $add1,
        "email" => $email,
        "phone" =>$phone
    );
    
    $fh = fopen("Book1.csv","a");
    fputcsv($fh,$data);
    fclose($fh);
?>
    
<html>
<head><style>
body{
background-image: url("sample.jpeg");
height:110%;
background-position:center;
background-repeat:no-repeat;
background-size:cover;
#wow{
margin-left:34;
background-color:white;
width:100;
height:40;}
}
</style>
</head>
<body><font color="white">
<legend><h1 class="title" id="page-title">
Please fill out the form for the certificate </h1></legend>
<form method="POST" action="thankyou.html"  >
<fieldset>
        Name:<br>   
         <input type="text" name="name" required ><br><br>  
         Reason for your visit outside: <br>  
         <input type="text" name="Reason" required ><br><br>
         Address: <br>  
         <input type="text" name="Add1" required ><br><br>  
         Email Id:<br>  
         <input type="email" name="email" required ><br><br>
         Phone Number: <br>
         <input type="phone" name="phone" required >
         <br><br>
         <input type="submit" value="Submit Request" required ><br>
</fieldset>
</form>
<?php  ?>
</font>
</body>
</html>